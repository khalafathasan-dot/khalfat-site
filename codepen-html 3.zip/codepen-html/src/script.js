document.querySelectorAll(".call-btn").forEach(function(btn) {
  btn.addEventListener("click", function() {
    const msg = this.getAttribute("data-msg");
    const choice = confirm(msg + "\n\nمیخوای واتساپ پیام بدی؟\n(OK = واتساپ، Cancel = تماس)");
    if (choice) {
      window.open("https://wa.me/989054604463?text=" + encodeURIComponent(msg), "_blank");
    } else {
      window.location.href = "tel:09054604463";
    }
  });
});